# Paket CAD/CFD NK 65-180/172 — R2

Paket ini berisi model hidrolik parametrik pompa sentrifugal untuk persiapan analisis CFD. Model dibuat dari data produk Grundfos `93052617` yang diberikan pengguna. Semua satuan geometri adalah **mm**.

## Data acuan OEM

| Parameter | Nilai |
|---|---:|
| Produk | NK 65-180/172 AA1F2S3ESBQQEOW1 |
| Diameter impeller aktual | 172 mm |
| Suction | DN80 |
| Discharge | DN65 |
| Putaran referensi | 2930 rpm |
| Debit nominal | 88,61 m³/h |
| Head nominal | 34,93 m |
| Fluida | Air, 50 °C |
| Densitas | 988 kg/m³ |
| Toleransi kurva | ISO 9906:2012 grade 2B |

## Asumsi geometri internal

Model STEP pabrikan yang tersedia adalah model mekanik eksternal dan tidak memuat bentuk saluran volute maupun sudu impeller. Karena itu, nilai berikut adalah asumsi rekayasa R2 yang harus diganti jika gambar impeller atau hasil pemindaian tersedia:

| Parameter | Nilai R2 |
|---|---:|
| Diameter inlet sudu D1 | 100 mm |
| Diameter hub | 48 mm |
| Lebar keluar impeller b2 | 20 mm |
| Jumlah sudu | 7 |
| Tebal sudu | 4 mm |
| Sudut inlet/outlet sudu | 22° / 30° |
| Tebal front/back shroud | 3 mm / 3 mm |
| Diameter interface rotor-stator | 184 mm |
| Lebar radial volute awal/akhir | 8 mm / 48 mm |
| Lebar aksial volute | 26 mm |

Nilai OEM dan asumsi dipisahkan di `pump_parameters.json` dan `pump_parameters.csv`.

## Isi paket

- `Pump_CFD_Assembly.step`: casing volute dan impeller sebagai dua solid terpisah.
- `Pump_CFD_Impeller.step`: impeller tertutup untuk CAD/manufaktur konseptual.
- `Pump_CFD_Impeller_OpenView.step`: front shroud disembunyikan untuk pemeriksaan sudu.
- `Pump_CFD_VoluteCasing.step`: casing volute.
- `Pump_CFD_FlowDomains.step`: inlet, rotating domain, dan stationary domain.
- `Pump_CFD_FullFluidDomain.step`: domain fluida kontinu untuk pemeriksaan dan meshing alternatif.
- `Pump_CFD_BoundaryMarkers.step`: marker bidang inlet dan outlet.
- `Pump_CFD_Inspection_Section.step`: potongan pemeriksaan internal.
- `Pump_CFD_Dimensioned_Layout.dxf`: layout 2D berdimensi.
- `Pump_CFD_preview.png`: pratinjau model.
- `model_validation.json`: validitas B-Rep, volume, bounding box, dan pemeriksaan overlap.
- `export_validation.json`: hasil impor ulang setiap STEP.

## Pembagian zona CFD

1. `InletFluid`: ekstensi suction sampai eye impeller.
2. `RotorFluid`: domain berputar yang berisi impeller, dipakai untuk MRF atau sliding mesh.
3. `StatorFluid`: volute dan pipa discharge yang diam.

Permukaan interface adalah silinder Ø184 mm. Untuk simulasi titik nominal, gunakan mass-flow outlet 88,61 m³/h atau sekitar 24,32 kg/s pada densitas 988 kg/m³. Inlet pressure absolut dan NPSHA belum tersedia dan harus ditentukan dari sistem instalasi sebelum analisis kavitasi.

## Status validasi

Semua solid utama lulus pemeriksaan B-Rep dan berhasil diimpor ulang dari STEP. Tidak ditemukan volume overlap antara casing, impeller, atau ketiga domain fluida. Validasi ini memastikan konsistensi CAD; hasilnya belum merupakan validasi performa CFD atau sertifikasi desain pompa.

